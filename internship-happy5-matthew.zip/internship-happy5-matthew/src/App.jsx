import React from 'react';
import Sidebar from './components/sidebar.jsx';
import Dashboard from './Page/Dashboard.jsx';
import './App.css';

function App() {
  return (
    <div className="app">
      <Sidebar />
      <Dashboard />
    </div>
  );
}

export default App;
