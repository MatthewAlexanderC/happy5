import React from 'react';
import '../css/CreateTaskButton.css';

function CreateTaskButton() {
  return (
    <div className="create-task">
      <button>
        <span className="plus-sign">+</span> Create new task
      </button>
    </div>
  );
}

export default CreateTaskButton;
