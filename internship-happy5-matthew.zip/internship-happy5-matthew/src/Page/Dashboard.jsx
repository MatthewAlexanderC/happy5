import React from 'react';
import TaskCard from '../components/TaskCard';
import CreateTaskButton from '../Part/CreateTaskButton';
import '../css/Dashboard.css';

function Dashboard() {
  const tasks = [
    { task: 'Q1 2019', period: 'January - March', title: 'Re-designed the zero-g doggie bags. No more spills!', percentage: 64 },
    { task: 'Q1 2019', period: 'January - March', title: 'Travel & Relocation Support', percentage: 12 },
    { task: 'Q2 2019', period: 'April - June', title: 'No Task Available', percentage: null },
    { task: 'Q3 2019', period: 'July - September', title: 'Bundle interplanetary analytics for improved transmission', percentage: 90 },
    { task: 'Q4 2019', period: 'October - December', title: 'Data Migration: Performance & Culture End Game', percentage: 63 },
  ];

  const groupedTasks = tasks.reduce((acc, task) => {
    if (!acc[task.task]) {
      acc[task.task] = [];
    }
    acc[task.task].push(task);
    return acc;
  }, {});

  return (
    <div className="dashboard">
      <h3>Product Roadmap</h3>
      <div className="task-container">
        {Object.entries(groupedTasks).map(([taskKey, tasks], index) => (
          <div key={index} className={`task-column ${tasks.length === 1 ? 'small-column' : ''}`}>
            <h4 className='task-period'>{tasks[0].task}</h4> 
            <h5 className='task-period'>{tasks[0].period}</h5> 
            {tasks.map((taskDetail, idx) => (
              <TaskCard 
                key={idx}
                task={taskDetail.task}
                period={taskDetail.period}
                title={taskDetail.title}
                percentage={taskDetail.percentage}
              />
            ))}
            <CreateTaskButton />
          </div>
        ))}
      </div>
    </div>
  );
}

export default Dashboard;
