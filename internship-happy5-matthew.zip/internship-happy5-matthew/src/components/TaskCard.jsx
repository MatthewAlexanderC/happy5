import React from 'react';
import '../css/TaskCard.css';

function TaskCard({ task, period, title, percentage }) {
  return (
    <div className="task-card">
      <div className="task-header">
        <h5>{title}</h5>
      </div>
      <div className="task-footer">
        {percentage !== null ? (
          <>
            <div className="task-percentage">
              <span className="lock-icon">&#128274;</span>
              <span>{percentage}%</span>
            </div>
            <div className="ellipsis-icon">•••</div>
          </>
        ) : null}
      </div>
    </div>
  );
}

export default TaskCard;
