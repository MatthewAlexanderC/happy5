import React from 'react';
import '../css/sidebar.css';
import logo from '../assets/logo.png'; 

function Sidebar() {
  return (
    <div className="sidebar">   
      <img src={logo} alt="Logo happy5" /> 
    </div>
  );
}

export default Sidebar;
